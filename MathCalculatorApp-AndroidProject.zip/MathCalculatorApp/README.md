# Math Calculator — Android App

This is a ready-to-open **Android Studio** project that wraps the offline
Math Calculator web app in a native Android WebView, so it installs and runs
like a normal Android app (no internet needed).

## What's inside
- `app/src/main/assets/index.html` — the calculator itself (unchanged from the web version)
- `app/src/main/java/com/mathcalculator/app/MainActivity.java` — loads the HTML in a full-screen WebView
- `app/src/main/AndroidManifest.xml`, `res/` — standard Android app scaffolding (icon, theme, strings)
- Gradle build files for Android Gradle Plugin 8.2 / Gradle 8.4

## How to build the APK

### Option A — Android Studio (easiest)
1. Install [Android Studio](https://developer.android.com/studio).
2. Choose **Open** and select this project's root folder (`MathCalculatorApp`).
3. Let Gradle sync (it will download the wrapper automatically).
4. Click **Run ▶** to install on an emulator/device, or
   **Build → Build Bundle(s) / APK(s) → Build APK(s)** to get an installable `.apk`.

### Option B — Command line
```bash
cd MathCalculatorApp
./gradlew assembleDebug
```
The APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

(On first run, `./gradlew` will download the Gradle distribution automatically —
you need an internet connection just for that step, and a JDK 17 installed.)

## App details
- App name: **Math Calculator**
- Package name: `com.mathcalculator.app`
- Minimum Android version: 5.0 (API 21)
- Works fully offline — the calculator logic runs inside the WebView

## Customizing
- To change the app name: edit `app/src/main/res/values/strings.xml`
- To change the icon: replace `app/src/main/res/drawable/ic_launcher_foreground.xml`
  and the color in `app/src/main/res/values/ic_launcher_background.xml`
- To update the calculator itself: edit `app/src/main/assets/index.html`
